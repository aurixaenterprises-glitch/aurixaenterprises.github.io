AURIXA Enterprises — one-page website

Files:
- index.html: complete responsive website.

Preview:
Open index.html in any modern browser.

Free publishing:
1. Create a GitHub account at https://github.com/
2. Create a new public repository named aurixaenterprises.github.io (or any repo name).
3. Upload index.html.
4. Open repository Settings → Pages.
5. Select Deploy from a branch, choose main and /(root), then Save.
6. GitHub Pages will provide a free public website address.

Note:
- aurixaenterprises.com is a custom domain and normally requires paid domain registration. It is not included with free hosting.
- The website currently uses the contact details supplied in the business-card reference.
- Replace the details in index.html if any contact information changes.
